package com.madgamer.ww2quests;


import com.badlogic.gdx.Game;
import com.madgamer.ww2quests.screens.NetScreen;

public class WW2Quests extends Game {
	private WW2Quests game;
	
	@Override
	public void create () {
		game = this;
		setScreen(new NetScreen(game));
	}

	@Override
	public void dispose () {super.dispose();}
}
