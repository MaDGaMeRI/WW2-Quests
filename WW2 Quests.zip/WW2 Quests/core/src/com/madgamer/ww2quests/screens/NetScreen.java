package com.madgamer.ww2quests.screens;

import static com.madgamer.ww2quests.utils.Constants.WORLD_HEIGHT;
import static com.madgamer.ww2quests.utils.Constants.WORLD_WIDTH;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.scenes.scene2d.Action;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.madgamer.ww2quests.WW2Quests;

public class NetScreen implements Screen {
    //Baza
    private final WW2Quests game;

    //Screen
    private Stage stage;
    private StretchViewport viewport;
    private OrthographicCamera camera;
    private Screen nextScreen;
    private Sprite map;

    public NetScreen(WW2Quests game) {this.game=game;}

    @Override
    public void show() {
        camera = new OrthographicCamera();
        viewport = new StretchViewport(1280, 720, camera);
        stage = new Stage(viewport);
        Skin skin = new Skin(Gdx.files.internal("skin/uiskin.json"));

        TextButton textButton = new TextButton("START GAME", skin);
        textButton.setPosition(550,130);
        textButton.setSize(180,60);
        textButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                nextScreen = new GameScreen(game);
            }
        });
        map = new Sprite(new Texture("Старт.png"));

        stage.addActor(textButton);
        Gdx.input.setInputProcessor(this.stage);
    }

    @Override
    public void render(float delta) {
        stage.getViewport().apply();

        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        Gdx.gl.glClearColor(0,0,0,0);

        stage.getBatch().begin();
        stage.getBatch().draw(map,0,0, 1280, 720);
        stage.getBatch().end();

        stage.draw();
        stage.act();
        if(nextScreen != null) {
            game.setScreen(nextScreen);
            nextScreen = null;
        }
    }

    @Override
    public void resize(int width, int height){stage.getViewport().update(width, height, true);}

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
