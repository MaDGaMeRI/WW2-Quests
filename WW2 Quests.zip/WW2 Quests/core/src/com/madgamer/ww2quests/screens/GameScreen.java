package com.madgamer.ww2quests.screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.Contact;
import com.badlogic.gdx.physics.box2d.ContactImpulse;
import com.badlogic.gdx.physics.box2d.ContactListener;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.Manifold;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.TimeUtils;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.madgamer.ww2quests.WW2Quests;
import com.madgamer.ww2quests.models.Arrows;
import com.madgamer.ww2quests.models.Bullet;
import com.madgamer.ww2quests.models.tanks.EnemyTank;
import com.madgamer.ww2quests.utils.Filler;
import com.madgamer.ww2quests.utils.EnemyTanks;
import com.madgamer.ww2quests.models.Trajectory;
import com.madgamer.ww2quests.models.tanks.PlayerTank;
import com.madgamer.ww2quests.utils.WorldContactListener;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;

import static com.madgamer.ww2quests.utils.Constants.ALIVE_THREADS;
import static com.madgamer.ww2quests.utils.Constants.BULLETS_PACKET_START;
import static com.madgamer.ww2quests.utils.Constants.GAME_OVER_PACKET;
import static com.madgamer.ww2quests.utils.Constants.ISFINDED;
import static com.madgamer.ww2quests.utils.Constants.PACKET_END;
import static com.madgamer.ww2quests.utils.Constants.SHOOT;
import static com.madgamer.ww2quests.utils.Constants.SHOOT_PACKET;
import static com.madgamer.ww2quests.utils.Constants.TANK_PACKET;
import static com.madgamer.ww2quests.utils.Constants.WORLD_HEIGHT;
import static com.madgamer.ww2quests.utils.Constants.WORLD_WIDTH;

public class GameScreen implements Screen {
    // Baza
    private final WW2Quests game;

    // Screen
    private Screen nextScreen;
    private Stage stage;
    private StretchViewport viewport;
    private OrthographicCamera camera;
    World world;
    Box2DDebugRenderer renderer;
    Arrows arrows;

    // Sprites
    private PlayerTank playertank;
    final private ArrayList<Bullet> bullets;
    private HashMap<Fixture, Object> fixtureObjectMap;
    private Sprite map;

    // Player
    private boolean isAlive = true;
    private OutputStream outputStream;
    private InputStream inputStream;
    private Thread thread;

    // Enemy
    private Filler course;
    private EnemyTanks enemyTanks;

    public GameScreen(WW2Quests game) {
        this.game = game;
        bullets = new ArrayList<>();
        course = new Filler();
    }

    @Override
    public void show() {
        camera = new OrthographicCamera();
        viewport = new StretchViewport(1280, 720, camera);
        stage = new Stage(viewport);

        Gdx.input.setInputProcessor(null);
        fixtureObjectMap = new HashMap<Fixture, Object>();

        world = new World(new Vector2(0, 0), false);
        renderer = new Box2DDebugRenderer();

        arrows = new Arrows(stage.getCamera());
        playertank = new PlayerTank(world, stage.getCamera(), WORLD_HEIGHT/2, 200);
        fixtureObjectMap.put(playertank.tankFixture, playertank);

        map = new Sprite(new Texture("ПОЛЕ_БОЯ.png"));
        course.added(world);
        enemyTanks = new EnemyTanks(course, viewport);
        enemyTanks.added(world, camera);

        stage.addActor(playertank);
        stage.addActor(arrows);

        playertank.setOnDestroy(new Runnable() {
            @Override
            public void run() {
                if (ALIVE_THREADS>0) {
                    ALIVE_THREADS--;
                    return;
                }

                isAlive = false;
                while (ALIVE_THREADS != 0) {
                    try {
                        Thread.sleep(10);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
                Gdx.app.postRunnable(new Runnable() {
                    @Override
                    public void run() {
                        game.setScreen(new GameOverScreen(game));
                    }
                });
            }
        });

        world.setContactListener(new WorldContactListener(fixtureObjectMap, bullets));
    }

    @Override
    public void render(float delta) {
        Array<Body> worldBodies = new Array<Body>();
        world.getBodies(worldBodies);
        for (Body body :
                worldBodies) {
            Object userData = body.getUserData();
            if (userData instanceof Bullet && ((Bullet) userData).shouldBeDestroyed)
                world.destroyBody(body);
            if (userData instanceof PlayerTank && ((PlayerTank) userData).shouldBeDestroyed)
                world.destroyBody(body);

        }

        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        Gdx.gl.glClearColor(1, 1, 1, 0);

        for (Trajectory trajectory : course.course) {
            trajectory.draw(stage, delta);
        }

        stage.getBatch().begin();
        stage.getBatch().draw(map,-400,200,968,648,1936,1296,2.0f,2.0f, 40);
        stage.getBatch().end();

        stage.getViewport().apply();
        world.step(delta, 6, 2);
        stage.act(delta);
        renderer.render(world, stage.getCamera().combined);

        if (SHOOT && playertank.canShoot()) {
            synchronized (bullets) {
                Bullet bullet = new Bullet(world, playertank, TimeUtils.millis());
                bullets.add(bullet);
                fixtureObjectMap.put(bullet.bulletFixture, bullet);
            }
            ISFINDED = true;
        }
        SHOOT = false;
        fixtureObjectMap = enemyTanks.shoots(fixtureObjectMap, world);
        for (int i=0; i<enemyTanks.bullets.size(); i++) {bullets.add(enemyTanks.bullets.get(i));}

        ArrayList<Bullet> disposedBullets = new ArrayList<Bullet>();
        synchronized (bullets) {
            for (Bullet bullet :
                    bullets) {
                if (bullet.bulletBody.getPosition().x > 1280 ||
                        bullet.bulletBody.getPosition().x < 0 ||
                        bullet.bulletBody.getPosition().y > 720 ||
                        bullet.bulletBody.getPosition().y < 0) {
                    bullet.dispose();
                    disposedBullets.add(bullet);
                }
            }

            enemyTanks.draw(delta, playertank);
            if (enemyTanks.listTanks.size()==0) {
                nextScreen = new GameWinScreen(game);
            }
            stage.draw();

            for (Bullet bullet : disposedBullets) {
                bullets.remove(bullet);
                fixtureObjectMap.remove(bullet.bulletFixture);
            }
            for (Bullet bullet :
                    bullets) {
                bullet.draw(stage, delta);
            }
        }
    }

    @Override
    public void resize(int width, int height){stage.getViewport().update(width, height, true);}

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        arrows.dispose();
        playertank.dispose();
        stage.dispose();
        world.dispose();
        renderer.dispose();
        isAlive = false;
    }
}
