package com.madgamer.ww2quests.screens;

import static com.madgamer.ww2quests.utils.Constants.WORLD_HEIGHT;
import static com.madgamer.ww2quests.utils.Constants.WORLD_WIDTH;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.net.Socket;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.madgamer.ww2quests.WW2Quests;
import com.madgamer.ww2quests.utils.Constants;

import java.io.StreamCorruptedException;

public class GameOverScreen implements Screen {
    WW2Quests game;
    BitmapFont text;
    Stage stage;
    Screen nextScreen;

    public GameOverScreen(WW2Quests game){this.game=game;}

    @Override
    public void show() {
        OrthographicCamera camera = new OrthographicCamera();
        StretchViewport viewport = new StretchViewport(1280, 720, camera);
        stage = new Stage(viewport);
        text = new BitmapFont();
        text.getData().setScale(5);
        Skin skin = new Skin(Gdx.files.internal("skin/uiskin.json"));

        TextButton textButton = new TextButton("RESTART GAME", skin);
        textButton.setPosition(500,250);
        textButton.setSize(180,60);
        textButton.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                nextScreen = new GameScreen(game);
            }});
        stage.addActor(textButton);
        Gdx.input.setInputProcessor(this.stage);
        Constants.ALIVE_THREADS=0;
        Constants.ISFINDED=false;
        Constants.SHOOT=false;
    }

    @Override
    public void render(float delta) {
        stage.getViewport().apply();
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        stage.getBatch().begin();
        text.draw(stage.getBatch(), "YOU LOSE!", 400, 400);
        stage.getBatch().end();
        stage.draw();
        stage.act();
        if(nextScreen != null) {
            game.setScreen(nextScreen);
            nextScreen = null;
        }
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
