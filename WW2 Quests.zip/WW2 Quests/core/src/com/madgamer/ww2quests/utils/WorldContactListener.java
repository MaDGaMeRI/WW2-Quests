package com.madgamer.ww2quests.utils;

import com.badlogic.gdx.physics.box2d.Contact;
import com.badlogic.gdx.physics.box2d.ContactImpulse;
import com.badlogic.gdx.physics.box2d.ContactListener;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.Manifold;
import com.madgamer.ww2quests.models.Bullet;
import com.madgamer.ww2quests.models.tanks.EnemyTank;
import com.madgamer.ww2quests.models.tanks.PlayerTank;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;

public class WorldContactListener implements ContactListener {
    private HashMap<Fixture, Object> fixtureObjectMap;
    private final ArrayList<Bullet> bullets;

    public WorldContactListener(HashMap<Fixture, Object> fixtureObjectMap, ArrayList<Bullet> bullets) {
        this.fixtureObjectMap = fixtureObjectMap;
        this.bullets = bullets;
    }
    @Override
    public void beginContact(Contact contact) {
        System.out.println("Contact!");
        if (!fixtureObjectMap.containsKey(contact.getFixtureA()))
            return;
        if (!fixtureObjectMap.containsKey(contact.getFixtureB()))
            return;
        Object tank = fixtureObjectMap.get(contact.getFixtureA()), bullet = fixtureObjectMap.get(contact.getFixtureB());

        if (tank instanceof Bullet && bullet instanceof Bullet) {
            contact.setEnabled(false);
            return;
        }
        if (tank instanceof PlayerTank && bullet instanceof Bullet) {
            ((PlayerTank) tank).dispose();
            return;
        }
        if (tank instanceof Bullet && bullet instanceof PlayerTank) {
            ((PlayerTank) bullet).dispose();
            return;
        }
        if (tank instanceof EnemyTank && bullet instanceof Bullet) {
            ((EnemyTank) tank).dispose();
            ((Bullet) bullet).dispose();
            return;
        }
        if (tank instanceof Bullet && bullet instanceof EnemyTank) {
            ((Bullet) tank).dispose();
            ((EnemyTank) bullet).dispose();
        }
    }

    @Override
    public void endContact(Contact contact) {
        return;
    }

    @Override
    public void preSolve(Contact contact, Manifold oldManifold) {
        return;
    }

    @Override
    public void postSolve(Contact contact, ContactImpulse impulse) {
        return;
    }
}
