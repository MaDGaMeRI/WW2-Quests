package com.madgamer.ww2quests.utils;

import static com.madgamer.ww2quests.utils.Constants.WORLD_WIDTH;

import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.TimeUtils;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.madgamer.ww2quests.models.Bullet;
import com.madgamer.ww2quests.models.tanks.EnemyTank;
import com.madgamer.ww2quests.models.tanks.PlayerTank;

import java.util.ArrayList;
import java.util.HashMap;

public class EnemyTanks {
    private Filler course;
    private Stage stage;
    public ArrayList<EnemyTank> listTanks;
    public ArrayList<Bullet> bullets;

    private World world;
    private Camera camera;

    public EnemyTanks(Filler course, StretchViewport viewport) {
        stage = new Stage(viewport);
        this.course = course;
        bullets = new ArrayList<>();
        listTanks = new ArrayList<>();
    }

    public void added(World world, Camera camera) {
        listTanks.add(new EnemyTank(world, camera, 1370, 580, 110, course));
        stage.addActor(listTanks.get(0));
        this.world = world; this.camera = camera;
    }

    public void draw(float delta, PlayerTank playerTank) {
        if (listTanks.get(listTanks.size()-1).nextTank && listTanks.size()<=5) {
            listTanks.add(new EnemyTank(world, camera, 1370, 580, 110, course));
            stage.addActor(listTanks.get(listTanks.size()-1));
            System.out.println(listTanks.size());
        }
        ArrayList<Integer> remove = new ArrayList<>();
        for (int i=0; i<listTanks.size(); i++) {
            listTanks.get(i).setPlayerTank(playerTank.getX(), playerTank.getY());
            if (listTanks.get(i).shouldBeDestroyed) {
                remove.add(i);
                System.out.println("111111111111111111111111111111");
            } else System.out.println(listTanks.get(i).shouldBeDestroyed);
        }
        for (int i=0; i<remove.size(); i++) {listTanks.remove(remove.get(i));}
        stage.act(delta);
        stage.draw();
    }

    public HashMap<Fixture, Object> shoots(HashMap<Fixture, Object> fixtureObjectMap, World world) {
        bullets = new ArrayList<>();
        for (int i=0; i<listTanks.size(); i++) {
            if (listTanks.get(i).shoot) {
                synchronized (bullets) {
                    Bullet bullet = new Bullet(world, listTanks.get(i), TimeUtils.millis());
                    bullets.add(bullet);
                    fixtureObjectMap.put(bullet.bulletFixture, bullet);
                }
            }
            listTanks.get(i).shoot = false;
        }
        return fixtureObjectMap;
    }

    public Actor getActor() {return stage.getActors().get(0);}
}
