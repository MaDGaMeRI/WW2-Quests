package com.madgamer.ww2quests.utils;

import com.badlogic.gdx.physics.box2d.World;
import com.madgamer.ww2quests.models.Trajectory;

import java.util.ArrayList;

public class Filler {
    public  ArrayList<Trajectory> course;
    public Filler(){
        course = new ArrayList<>();
    }

    public void added(World world) {
        course.add(new Trajectory(world, 1240, 540));
        course.add(new Trajectory(world, 1091, 522));
        course.add(new Trajectory(world, 938, 511));
        course.add(new Trajectory(world, 763, 495));
        course.add(new Trajectory(world, 667, 471));
        course.add(new Trajectory(world, 585, 475));
        course.add(new Trajectory(world, 430, 480));
        course.add(new Trajectory(world, 304, 462));
        course.add(new Trajectory(world, 247, 404));
        course.add(new Trajectory(world, 251, 201));
        course.add(new Trajectory(world, 250, -9));
    }
}
