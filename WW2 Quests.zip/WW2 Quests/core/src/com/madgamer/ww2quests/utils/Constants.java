package com.madgamer.ww2quests.utils;

import com.badlogic.gdx.Gdx;

public class Constants {
    public static final float TANK_SPEED = 10.0f;
    public static final float BULLET_SPEED = 1000000000;
    public static final float WORLD_WIDTH = Gdx.graphics.getWidth();
    public static final float WORLD_HEIGHT = Gdx.graphics.getHeight();
    public static boolean ISFINDED = false;

    public static boolean UP, DOWN, ROTATE_LEFT_BODY, ROTATE_LEFT_TURRET, ROTATE_RIGHT_BODY, ROTATE_RIGHT_TURRET, SHOOT = false, CHECK = true;

    public static int ALIVE_THREADS = 5;
    public static final String TANK_PACKET = "TANK";
    public static final String BULLETS_PACKET_START = "BULLETS";
    public static final String SHOOT_PACKET = "SHOOT";
    public static final String PACKET_END = "PACKET_END";
    public static final String GAME_OVER_PACKET = "GAME_OVER";
}
