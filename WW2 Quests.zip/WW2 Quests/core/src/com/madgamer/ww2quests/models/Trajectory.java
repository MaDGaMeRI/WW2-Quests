package com.madgamer.ww2quests.models;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Stage;

public class Trajectory {
    private World world;
    ShapeRenderer renderer;
    public Body dotBody;
    public Fixture dotFixture;

    public Trajectory(World world, float x, float y) {
        this.world = world;
        renderer = new ShapeRenderer();

        createCircle(x, y);
    }

    private void createCircle(float x, float y) {
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.StaticBody;

        bodyDef.position.set(x, y);
        dotBody = world.createBody(bodyDef);
        dotBody.setUserData(this);

        CircleShape shape = new CircleShape();

        //dotFixture = dotBody.createFixture(shape,1.0f);
        //dotFixture.setRestitution(1.0f);
        //dotFixture.setFriction(0);

        shape.dispose();
    }

    public void draw(Stage stage, float delta) {
        renderer.setProjectionMatrix(stage.getCamera().combined);
        renderer.begin(ShapeRenderer.ShapeType.Filled);
        renderer.setColor(Color.BLUE);
        renderer.circle(dotBody.getPosition().x,
                dotBody.getPosition().y, 20);
        renderer.end();
    }

    public Body getDotBody() {return dotBody;}
}
