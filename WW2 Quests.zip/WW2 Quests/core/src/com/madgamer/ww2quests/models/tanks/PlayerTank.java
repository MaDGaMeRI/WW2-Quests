package com.madgamer.ww2quests.models.tanks;

import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.physics.box2d.World;

public class PlayerTank extends Tank{

    public PlayerTank(World world, Camera camera, float pX, float pY) {
        super(world, camera, pX, pY, "КВ-1");
    }

    public boolean canShoot() {return canShoot(3000);}

    public void dispose() {
        if (onDestroyRunnable != null)
            onDestroyRunnable.run();
    }
}
