package com.madgamer.ww2quests.models.tanks;

import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.utils.TimeUtils;
import com.madgamer.ww2quests.models.Bullet;
import com.madgamer.ww2quests.utils.Constants;

import java.util.HashSet;
import java.util.Set;

import static com.madgamer.ww2quests.utils.Constants.DOWN;
import static com.madgamer.ww2quests.utils.Constants.ROTATE_LEFT_BODY;
import static com.madgamer.ww2quests.utils.Constants.ROTATE_LEFT_TURRET;
import static com.madgamer.ww2quests.utils.Constants.ROTATE_RIGHT_BODY;
import static com.madgamer.ww2quests.utils.Constants.ROTATE_RIGHT_TURRET;
import static com.madgamer.ww2quests.utils.Constants.UP;

public class Tank extends Actor {
    // Baza
    protected final World world;
    Camera camera;

    // Sprites
    protected Set<Bullet> bullets;
    Texture bodyTexture, turretTexture;
    Sprite bodySprite, turretSprite;
    protected Body tankBody;
    Vector2 tankPosition;
    public float bodyAlpha = 0, turretAlpha = 0;
    public Fixture tankFixture;

    // Vzaimodeistvya
    public boolean shouldBeDestroyed = false;
    protected long lastShoot;
    protected Runnable onDestroyRunnable;


    public Tank(World world, Camera camera, float pX, float pY, String tankStr) {
        this.world = world;
        this.camera = camera;
        this.bullets = new HashSet<Bullet>();

        tankPosition = new Vector2(pX, pY);
        createCircle(this.world, tankPosition.x, tankPosition.y);

        bodyTexture = new Texture(tankStr+"_КОРПУС_НОВЫЙ.png");
        turretTexture = new Texture(tankStr+"_БАШНЯ_НОВАЯ.png");
        bodySprite = new Sprite(bodyTexture);
        bodySprite.setPosition(pX, pY);
        turretSprite = new Sprite(turretTexture);
        turretSprite.setPosition(pX, pY);
    }

    public boolean canShoot(long reload) {
        return TimeUtils.millis() - lastShoot >= reload;
    }

    public void addBullet(Bullet bullet) {
        lastShoot = TimeUtils.millis();
        bullets.add(bullet);
    }

    public void removeBullet(Bullet bullet) {
        bullets.remove(bullet);
    }

    public void act(float delta) {
        tankPosition.x = getTankBody().getPosition().x;
        tankPosition.y = getTankBody().getPosition().y;

        if (UP) {
            getTankBody().setLinearVelocity(getTankBody().getLinearVelocity().x -= Constants.TANK_SPEED * Math.sin(bodyAlpha * Math.PI / 180.0f) * delta,
                    getTankBody().getLinearVelocity().y += Constants.TANK_SPEED * Math.cos(bodyAlpha * Math.PI / 180.0f) * delta);
        }

        if (DOWN) {
            getTankBody().setLinearVelocity(getTankBody().getLinearVelocity().x += Constants.TANK_SPEED * Math.sin(bodyAlpha * Math.PI / 180.0f) * delta,
                    getTankBody().getLinearVelocity().y -= Constants.TANK_SPEED * Math.cos(bodyAlpha * Math.PI / 180.0f) * delta);
        }

        if (ROTATE_LEFT_BODY) {
            bodyAlpha += 0.5f;
            turretAlpha += 0.5f;
            if (bodyAlpha >= 180) bodyAlpha -= 360;
            else if (bodyAlpha < -180) bodyAlpha += 360;
            if (turretAlpha >= 180) turretAlpha -=360;
            else if (turretAlpha < -180) turretAlpha += 360;
        }

        if (ROTATE_RIGHT_BODY) {
            bodyAlpha -= 0.5f;
            turretAlpha -= 0.5f;
            if (bodyAlpha >= 180) bodyAlpha -= 360;
            else if (bodyAlpha < -180) bodyAlpha += 360;
            if (turretAlpha >= 180) turretAlpha -=360;
            else if (turretAlpha < -180) turretAlpha += 360;
        }

        if (ROTATE_LEFT_TURRET) {
            turretAlpha += 0.25f;
            if (turretAlpha >= 180) turretAlpha -=360;
            else if (turretAlpha < -180) turretAlpha += 360;
        }

        if (ROTATE_RIGHT_TURRET) {
            turretAlpha -= 0.25f;
            if (turretAlpha >= 180) turretAlpha -=360;
            else if (turretAlpha < -180) turretAlpha += 360;
        }

        if (!UP && !DOWN && !ROTATE_LEFT_BODY && !ROTATE_RIGHT_BODY && !ROTATE_LEFT_TURRET && !ROTATE_RIGHT_TURRET) {
            getTankBody().setLinearVelocity(0, 0);
        }

        setX(tankPosition.x);
        setY(tankPosition.y);
    }

    public void draw(Batch batch, float parentAlpha) {
        batch.setProjectionMatrix(camera.combined);
        if (!shouldBeDestroyed){
        batch.draw(bodySprite, tankPosition.x - (bodySprite.getWidth() / 2),
                tankPosition.y - (bodySprite.getHeight() / 2),
                bodySprite.getWidth() / 2,
                bodySprite.getHeight() / 2,
                bodySprite.getWidth(),
                bodySprite.getHeight(),
                getScaleX(), getScaleY(), bodyAlpha);
        batch.draw(turretSprite, tankPosition.x - (turretSprite.getWidth() / 2),
                tankPosition.y - (turretSprite.getHeight() / 2),
                turretSprite.getWidth() / 2,
                turretSprite.getHeight() / 2,
                turretSprite.getWidth(),
                turretSprite.getHeight(),
                getScaleX(), getScaleY(), turretAlpha);
    }}

    private void createCircle(World world, float x, float y) {
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.DynamicBody;

        bodyDef.position.set(x, y);
        tankBody = world.createBody(bodyDef);
        getTankBody().setUserData(this);
        CircleShape shape = new CircleShape();
        shape.setRadius(20.0f);

        tankFixture = getTankBody().createFixture(shape, 1.0f);
        tankFixture.setFriction(0);
        shape.dispose();
    }

    public void dispose() {
        bodyTexture.dispose();
        turretTexture.dispose();
        if (onDestroyRunnable != null)
            onDestroyRunnable.run();
        ((Tank) getTankBody().getUserData()).shouldBeDestroyed = true;
        shouldBeDestroyed = true;
    }

    public void setOnDestroy(Runnable onDestroyRunnable) {
        this.onDestroyRunnable = onDestroyRunnable;
    }

    public Body getTankBody() {
        return tankBody;
    }
}
