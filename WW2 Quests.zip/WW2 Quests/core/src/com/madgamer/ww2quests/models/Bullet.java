package com.madgamer.ww2quests.models;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.madgamer.ww2quests.models.tanks.Tank;

import static com.madgamer.ww2quests.utils.Constants.BULLET_SPEED;

public class Bullet {
    // Baza
    private World world;
    ShapeRenderer renderer;

    // Sprites
    public Body bulletBody;
    Tank tank;
    public Fixture bulletFixture;
    public float alpha = 0;

    // Vzaimodeystvya
    public long spawnTime;
    public boolean shouldBeDestroyed = false;

    public Bullet(World world, Tank tank, long spawnTime) {
        this.world = world;
        this.tank = tank;
        this.spawnTime = spawnTime;
        renderer = new ShapeRenderer();
        alpha = tank.turretAlpha;

        createCircle(this.world, tank.getTankBody().getPosition().x - 30 * (float) Math.cos((tank.turretAlpha - 90) * Math.PI / 180.0f),
                tank.getTankBody().getPosition().y - 30 * (float) Math.sin((tank.turretAlpha - 90) * Math.PI / 180.0f));

        bulletBody.setLinearVelocity( -(float) Math.cos((alpha - 90) * Math.PI / 180.0f) * 2 * BULLET_SPEED ,
                -(float) Math.sin((alpha - 90) * Math.PI / 180.0f) * 2 * BULLET_SPEED );
        tank.addBullet(this);
    }

    public void draw(Stage stage, float delta) {

        renderer.setProjectionMatrix(stage.getCamera().combined);
        renderer.begin(ShapeRenderer.ShapeType.Filled);
        renderer.setColor(Color.BLACK);
        renderer.circle(bulletBody.getPosition().x,
                bulletBody.getPosition().y, 5);
        renderer.end();
    }

    private void createCircle(World world, float x, float y) {
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.DynamicBody;

        bodyDef.position.set(x, y);
        bulletBody = world.createBody(bodyDef);
        bulletBody.setUserData(this);
        bulletBody.setBullet(true);

        CircleShape shape = new CircleShape();
        shape.setRadius(5.0f);

        bulletFixture = bulletBody.createFixture(shape, 1.0f);
        bulletFixture.setRestitution(1.0f);
        bulletFixture.setFriction(0);

        shape.dispose();
    }

    public void dispose() {
        tank.removeBullet(this);
        renderer.dispose();
        bulletBody.destroyFixture(bulletFixture);
        ((Bullet) bulletBody.getUserData()).shouldBeDestroyed = true;
    }

    public Body getBulletBody() {
        return bulletBody;
    }
}
