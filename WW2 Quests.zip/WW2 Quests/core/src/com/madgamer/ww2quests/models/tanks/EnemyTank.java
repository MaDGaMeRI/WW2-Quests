package com.madgamer.ww2quests.models.tanks;

import static com.madgamer.ww2quests.utils.Constants.ISFINDED;
import static java.lang.Math.cos;
import static java.lang.Math.sqrt;

import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.TimeUtils;
import com.madgamer.ww2quests.models.Bullet;
import com.madgamer.ww2quests.utils.Constants;
import com.madgamer.ww2quests.utils.Filler;

public class EnemyTank extends Tank{
    private Filler courses;
    private ShapeRenderer renderer;
    private boolean povorot = true;
    public boolean nextTank = false;
    public boolean shoot = false;
    private double xForPlayer, yForPlayer, degForPlayer=1000000, degPovernulsya=0;


    public EnemyTank(World world, Camera camera, float pX, float pY, float alpha, Filler courses) {
        super(world, camera, pX, pY, "Pz-3");
        this.bodyAlpha = alpha; this.turretAlpha = alpha;
        this.courses = courses;
    }

    public boolean canShoot() {return canShoot(5000);}

    @Override
    public void act(float delta) {
        if (!ISFINDED) {
            Vector2 coursePosition = new Vector2();
            double distance;
            double minDistance = 1000000;
            boolean success;
            float deltaXdist=0, deltaYdist=0, courseAlpha;

            for (int i = 0; i<courses.course.size(); i++) {
                coursePosition = courses.course.get(i).getDotBody().getPosition();
                success = false;
                if (bodyAlpha==0) {if (coursePosition.y > tankPosition.y) success = true;}
                else if (bodyAlpha==180) {if (coursePosition.y < tankPosition.y) success = true;}
                else if (bodyAlpha==90) {if (coursePosition.x < tankPosition.x) success = true;}
                else if (bodyAlpha==270) {if (coursePosition.x > tankPosition.x) success = true;}
                else if (bodyAlpha<90 || bodyAlpha>270) {
                    float deltaX, deltaY;
                    deltaX = coursePosition.x-tankPosition.x;
                    deltaY = (float) Math.tan(Math.toRadians(bodyAlpha))*deltaX;
                    if (tankPosition.y+deltaY<coursePosition.y) success = true;}
                else {
                    float deltaX, deltaY;
                    deltaX = coursePosition.x-tankPosition.x;
                    deltaY = (float) Math.tan(Math.toRadians(bodyAlpha))*deltaX;
                    if (tankPosition.y+deltaY>coursePosition.y) success = true;}

                if (success) {
                    distance = sqrt((tankPosition.y - coursePosition.y) * (tankPosition.y - coursePosition.y) + (tankPosition.x - coursePosition.x) * (tankPosition.x - coursePosition.x));
                    if (distance < minDistance) {
                        if (i!=0) nextTank = true;
                        minDistance = distance;
                        deltaXdist = tankPosition.x - coursePosition.x;
                        deltaYdist = tankPosition.y - coursePosition.y;
                    }
                }
            }
            if (deltaYdist==0) {
                if (deltaXdist>0) courseAlpha=-90;
                else courseAlpha=90;
            } else if (deltaXdist==0) {
                if (deltaYdist>0) courseAlpha=0;
                else courseAlpha=180;
            } else {
                float Alpha = (float) (Math.toDegrees(Math.atan2(deltaYdist, deltaXdist)));
                if (deltaYdist<0) {
                    if (Alpha<0) Alpha+=180;
                    courseAlpha = Alpha;
                } else { // deltaYdist < 0
                    if (Alpha<0) Alpha+=180;
                    Alpha+=180;
                    courseAlpha = Alpha;
                }
            }

            courseAlpha -= 90 + bodyAlpha ; // courseAlpha is found!
            bodyAlpha += courseAlpha/100;
            turretAlpha += courseAlpha/100;

            getTankBody().setLinearVelocity(-(float) (1000*Math.cos((bodyAlpha-90) * Math.PI / 180.0f) * delta),
                    -(float) (1000*Math.sin((bodyAlpha-90) * Math.PI / 180.0f) * delta));
            tankPosition.x = getTankBody().getPosition().x;
            tankPosition.y = getTankBody().getPosition().y;
        } else if (degForPlayer==1000000){
            if (getTankBody().getLinearVelocity().x!=0 || getTankBody().getLinearVelocity().y!=0) getTankBody().setLinearVelocity(0,0);
            double deltaX=xForPlayer-tankPosition.x;
            if (deltaX==0) {
                if (yForPlayer-tankPosition.y>0) degForPlayer=0;
                else degForPlayer=180;
            } else if (deltaX > 0) {
                degForPlayer = Math.toDegrees(Math.atan2(yForPlayer-tankPosition.y, deltaX))-turretAlpha+90;
            } else {
                degForPlayer = Math.toDegrees(Math.atan2(yForPlayer-tankPosition.y, deltaX))-turretAlpha+90+180;
            }
        } else if (povorot){
            turretAlpha += (float) (degForPlayer/3*delta);
            degPovernulsya += degForPlayer/3*delta;
            if (Math.abs(degPovernulsya)>Math.abs(degForPlayer)) {
                turretAlpha += degForPlayer - degPovernulsya;
                povorot = false;
            }
        } else {
            if (canShoot()) {
                shoot = true;
            }
        }
    }

    public void draw(Batch batch, float parentAlpha) {super.draw(batch, parentAlpha);}

    public void setPlayerTank(double x, double y) {xForPlayer=x;yForPlayer=y;}
}
