package com.madgamer.ww2quests.models;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;

import static com.madgamer.ww2quests.utils.Constants.ISFINDED;
import static com.madgamer.ww2quests.utils.Constants.UP;
import static com.madgamer.ww2quests.utils.Constants.DOWN;
import static com.madgamer.ww2quests.utils.Constants.ROTATE_LEFT_BODY;
import static com.madgamer.ww2quests.utils.Constants.ROTATE_LEFT_TURRET;
import static com.madgamer.ww2quests.utils.Constants.ROTATE_RIGHT_BODY;
import static com.madgamer.ww2quests.utils.Constants.ROTATE_RIGHT_TURRET;
import static com.madgamer.ww2quests.utils.Constants.SHOOT;

public class Arrows extends Actor {
    Camera camera;
    Vector3 touchPos;
    private BitmapFont Score1;
    private BitmapFont Score2;

    Stage stage;
    public static BitmapFont font, shadow;

    private Texture up, down, left, right, shoot;
    private Sprite upSprite, downSprite, leftSpriteBd, rightSpriteBd, shootSprite, leftSpriteTr, rightSpriteTr;

    public Arrows(Camera camera) {
        this.camera = camera;

        Score1 = new BitmapFont(); Score2 = new BitmapFont();
        Score1.setColor(Color.BLACK); Score2.setColor(Color.BLACK);

        up = new Texture("arrows/up.png"); upSprite = new Sprite(up);
        down = new Texture("arrows/down.png"); downSprite = new Sprite(down);
        left = new Texture("arrows/left.png"); leftSpriteBd = new Sprite(left); leftSpriteTr = new Sprite(left);
        right = new Texture("arrows/right.png"); rightSpriteBd = new Sprite(right); rightSpriteTr = new Sprite(right);
        shoot = new Texture("arrows/shoot.png"); shootSprite = new Sprite(shoot);
        touchPos = new Vector3();
    }

    @Override
    public void act(float delta) {
        UP=false;DOWN=false;
        ROTATE_LEFT_BODY=false;ROTATE_LEFT_TURRET=false;
        ROTATE_RIGHT_BODY=false;ROTATE_RIGHT_TURRET=false;

        for (int i = 0; i < 10; i++) {
            if (Gdx.input.isTouched(i)) {
                touchPos.set(Gdx.input.getX(i), Gdx.input.getY(i), 0);
                camera.unproject(touchPos);

                if (touchPos.x > 20+upSprite.getWidth() && touchPos.x < 20 + 2*upSprite.getWidth() && touchPos.y < upSprite.getHeight() + upSprite.getHeight()
                        && touchPos.y > upSprite.getHeight() && !ISFINDED) {
                    UP = true;
                } else {
                    UP = false;
                }

                if (touchPos.x > 20+upSprite.getWidth() && touchPos.x < 20 + 2*downSprite.getWidth() && touchPos.y < downSprite.getHeight() && touchPos.y > 0 && !ISFINDED) {
                    DOWN = true;
                } else {
                    DOWN = false;
                }

                if (touchPos.x > 10 && touchPos.x < 10+leftSpriteBd.getWidth() && touchPos.y < 1.5*leftSpriteBd.getHeight() && touchPos.y > 0.5*leftSpriteBd.getHeight() && !ISFINDED) {
                    ROTATE_LEFT_BODY = true;
                } else {
                    ROTATE_LEFT_BODY = false;
                }

                if (touchPos.x > 30+2*rightSpriteBd.getWidth() && touchPos.x < 30+3*rightSpriteBd.getWidth() && touchPos.y < 1.5*rightSpriteBd.getHeight() && touchPos.y > 0.5*rightSpriteBd.getHeight() && !ISFINDED) {
                    ROTATE_RIGHT_BODY = true;
                } else {
                    ROTATE_RIGHT_BODY = false;
                }

                if (touchPos.x > 956 && touchPos.x < 956+leftSpriteTr.getWidth() && touchPos.y < leftSpriteTr.getHeight() && touchPos.y > 0) {
                    ROTATE_LEFT_TURRET = true;
                } else {ROTATE_LEFT_TURRET=false;}
                if (touchPos.x > 1172 && touchPos.x < 1172+rightSpriteTr.getWidth() && touchPos.y < rightSpriteTr.getHeight() && touchPos.y > 0) {
                    ROTATE_RIGHT_TURRET = true;
                } else {ROTATE_RIGHT_TURRET=false;}
            }

            if (Gdx.input.isTouched(i)) {
                touchPos.set(Gdx.input.getX(i), Gdx.input.getY(i), 0);
                camera.unproject(touchPos);

                if (touchPos.x > 1064 && touchPos.x < 1172 &&
                        touchPos.y < shootSprite.getHeight() + 72 && touchPos.y > shootSprite.getHeight()) {
                    SHOOT = true;
                }
            }
        }
    }

    @Override
    public void draw(Batch batch, float parentAlpha) {
        batch.setProjectionMatrix(camera.combined);
        batch.draw(upSprite, 20+upSprite.getWidth(), upSprite.getHeight());
        batch.draw(downSprite, 20+downSprite.getWidth(), 0);
        batch.draw(leftSpriteBd, 10, upSprite.getHeight()/2);
        batch.draw(rightSpriteTr, 1172, 0);
        batch.draw(shootSprite, 1064, 72);
        batch.draw(rightSpriteBd, 30+2*upSprite.getWidth(), upSprite.getHeight()/2);
        batch.draw(leftSpriteTr, 956, 0);
    }

    public void dispose() {
        up.dispose();
        down.dispose();
        right.dispose();
        left.dispose();
        shoot.dispose();
        shadow.dispose();
        font.dispose();
    }
}
